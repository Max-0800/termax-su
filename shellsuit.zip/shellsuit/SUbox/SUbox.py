import os

#Master variables (do not change)
igpu = "/sys/kernel/gpu"
cluster1 = "/sys/devices/system/cpu/cpufreq/policy0"
for cnum in range(1,9):
	hostdir = "/sys/devices/system/cpu/cpufreq/policy"
	if os.path.isdir(f"{hostdir}{cnum}") == True:
		cluster2 = f"{hostdir}{cnum}"
		break


c1cur = open(f"{cluster1}/scaling_max_freq", "r").read()
c2cur = open(f"{cluster2}/scaling_max_freq", "r").read()


c1av = open(f"{cluster1}/scaling_available_frequencies","r").read().split()
c2av = open(f"{cluster2}/scaling_available_frequencies","r").read().split()
c1gv = open(f"{cluster1}/scaling_available_governors","r").read()
c2gv = open(f"{cluster2}/scaling_available_governors","r").read()
gpa = open(f"{igpu}/gpu_freq_table").read()

#performance management
#CPU
def cpu_setsafe(cluster, clock_value, clocks):
	if ("." in clock_value):
		try:
			x = f"{clock_value[0]}{clock_value[2:4]}"
		except:
			pass
		for value in clocks:
			if x in value:
				os.system(f"echo '{value}' > {cluster}/scaling_max_freq")
	elif "mhz" in clock_value:
		try:
			xi = f"{clock_value[0:3]}"
		except:
			exit()
		for values in clocks:
			if xi in values:
				os.system(f"echo '{values}' > {cluster}/scaling_max_freq")
	else:
		for value in clocks:
			if clock_value in value:
				os.system(f"echo '{value}' > {cluster}/scaling_max_freq")

def cpu_setforce(cluster, clock_value):
	os.system(f"echo '{clock_value}' > {cluster}/scaling_max_freq")

def cpu_gov_set(cluster, gov):
	os.system(f"echo '{gov}' > {cluster}/scaling_governor")

#iGPU
def gpu_set(clock, clocks):
	if clock in clocks:
		os.system(f"echo '{clock}' > /sys/kernel/gpu/gpu_max_clock")

def gpu_gov_set(gov):
	os.system(f"echo '{gov}' > /sys/kernel/gpu/gpu_governor")


#Status
#CPU
def cpu_available(exception, c1a, c2a, c1g, c2g):
	if exception == False:
		print("\nCluster 1 options")
		for intr in c1a:
			if len(intr) > 6:
				print(f"{intr[0]}.{intr[1:3]}Ghz")
			elif len(intr) < 7:
				print(f"{intr[0:3]}Mhz")
		print(c1g)
	
		print("Cluster 2 options")
		for intx in c2a:
			if len(intx) > 6:
				print(f"{intx[0]}.{intx[1:3]}Ghz")
			elif len(intx) < 7:
				print(f"{intx[0:3]}Mhz")
		print(c2g)
	elif exception == True:
		print("outputraw=TRUE\n\nCluster 1 options")
		print(f"{c1a}\n{c1g}")
		print("Cluster 2 options")
		print(f"{c2a}\n{c2g}")

#iGPU
def igpu_available():
	os.system(f"cat {igpu}/gpu_freq_table")
	os.system(f"cat {igpu}/gpu_available_governor")


#status info
def cpu_cluster1_status():
	os.system(f"cat {cluster1}/scaling_max_freq")
	os.system(f"cat {cluster1}/scaling_governor")

def cpu_cluster2_status():
	os.system(f"cat {cluster2}/scaling_max_freq")
	os.system(f"cat {cluster2}/scaling_governor")

def igpu_status():
	print("iGPU current state")
	os.system(f"cat {igpu}/gpu_max_clock")
	os.system(f"cat {igpu}/gpu_governor")


#sudo suite
def rotate_screen(value):
	os.system(f"settings put system user_rotation {value}")

def clear_cache():
	os.system("rm -rf storage/elumated/0/Android/data/*/cache /data/data/*/cache")