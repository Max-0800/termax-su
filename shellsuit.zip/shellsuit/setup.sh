cd $HOME
pkg update -y && pkg upgrade -y && pkg install x11-repo root-repo tsu python3 -y
unzip termax-su/termax.zip && mv termax-su/termax $HOME && mv termax-su/LISCENCE $HOME
rm -rf termax-su
echo "Thanks for installing Termax-SU - Max-0800"