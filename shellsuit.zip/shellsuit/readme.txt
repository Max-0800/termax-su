this project was created for the tech savvy programmers/hackers who want a cooler way of underclocking their android device, i am not held responsible for any damage done with or without this program.

User discretion is advised, use at your own risk.


Brought to you by Max-0800

General Public License (GPL) v3.0