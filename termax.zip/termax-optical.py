from SUbox import SUbox as root
import os

#go away - Max-0800 (before)
#gamers lol - Max-0800 (after)
#brain hurty - Max-0800 (future)

os.system("clear")

print('''
 Termax Optical
 v2.01
 by Max-0800
''')

cluster1 = root.cluster1
cluster2 = root.cluster2
gpa = root.gpa
c1a = root.c1a
c2a = root.c2a
c1g = root.c1g
c2g = root.c2g

def main():
	global cluster1
	global cluster2
	global gpa
	global c1a
	global c2a
	global c1g
	global c2g
	
	tmx = input("/sys/:> ")
	xvar= tmx[9:14]
	
	#CPU changing statements
	if "cpu -cm1 " in tmx:
		root.cpu_set(cluster1, xvar, c1a)
		print("Operation success.")
		
	elif "cpu -cm2 " in tmx:
		root.cpu_set(cluster2, xvar, c2a)
		print("Operation success.")
		
	#CPU governor changing statements
	if "cpu -gm1 " in tmx:
		root.cpu_gov_set(cluster1, xvar)
		print("Operation success.")
	elif "cpu -gm2 " in tmx:
		root.cpu_gov_set(cluster2, xvar)
		print("Operationg success.")
	
	#iGPU changing statements
	if "gpu -clk " in tmx:
		root.gpu_set(xvar, gpa)
		print(f"iGPU clock speed has been set to {xvar}Mhz")
	elif "gpu -gov " in tmx:
		root.gpu_gov_set(xvar)
		print(f"iGPU governor has been set to {xvar}")
	
	#Informational statements
	if tmx == "cpu -c":
		root.cpu_available(c1a, c2a, c1g, c2g)
	elif tmx == "cpu -si":
		root.cpu_cluster1_status()
		root.cpu_cluster2_status()
	if tmx == "gpu -c":
		root.igpu_available()
	elif tmx == "gpu -si":
		root.igpu_status()
	
	#Miscellaneous
	if tmx == "sudo reboot":
		os.system("sudo reboot")
	elif tmx == "clear cache":
		root.clear_cache()
		print("cache cleared")
	
	if tmx == "help":
		print("Commands")
		print('''
	≡Setting≡
gpu -clk <num>		sets desired clock speed to the integrated graphics unit
gpu -gov <gov>		sets desired governor to the graphics unit
cpu -cm1 <num>		sets desired clock speed to cluster 1
cpu -cm2 <num>		sets desired clock speed to cluster 2
cpu -gm1 <gov>		sets desired governor to cluster 1
cpu -gm2 <gov>		sets desired governor to cluster 2

	≡Informational≡
gpu -si			shows current GPU clock speed and GPU governor
gpu -c			shows available GPU clock speeds
cpu -si			shows current CPU clock speed and CPU governor
cpu -c			shows available CPU clock speeds

	≡Miscellaneous≡
sudo reboot		reboots device
clear cache		clears all cache
cls			clears the screen

note: program does not support single core clocking.\n\n please use the prefix 'ghz' for setting the clock speeds ex: cpu -cm1 1.80ghz''')
	elif tmx == "cls":
		os.system("clear")
	
	if "porn" in tmx:
		print("no horni")
	elif "hentai" in tmx:
		print("no horni, and get a life")
	if "sex" in tmx:
		print("ew?")

#Loopback
while True:
	main()