import os

#Master variables (do not change)
igpu = "/sys/kernel/gpu"
cluster1 = "/sys/devices/system/cpu/cpufreq/policy0"
for cnum in range(1,9):
	hostdir = "/sys/devices/system/cpu/cpufreq/policy"
	if os.path.isdir(f"{hostdir}{cnum}") == True:
		cluster2 = f"{hostdir}{cnum}"
		break


#performance management
#CPU
def cpu_set(cluster, clock):
	os.system(f"echo '{clock}' > {cluster}/scaling_max_freq")

def cpu_gov_set(cluster, gov):
	os.system(f"echo '{gov}' > {cluster}/scaling_governor")

#iGPU
def gpu_set(clock):
	os.system(f"echo '{clock}' > /sys/kernel/gpu_max_clock")

def gpu_gov_set(gov):
	os.system(f"echo '{gov}' > /sys/kernel/gpu_governor")


#Status
#availability
def cpu_available():
	print("Cluster 1")
	os.system(f"cat {cluster1}/scaling_available_frequencies")
	os.system(f"cat {cluster1}/scaling_available_governors")
	print("\nCluster 2")
	os.system(f"cat {cluster2}/scaling_available_frequencies")
	os.system(f"cat {cluster2}/scaling_available_governors")

def igpu_available():
	os.system(f"cat {igpu}/gpu_freq_table")
	os.system(f"cat {igpu}/gpu_available_governor")

#status info
def cpu_cluster1_status():
	os.system(f"cat {cluster1}/scaling_max_freq")
	os.system(f"cat {cluster1}/scaling_governor")
def cpu_cluster2_status():
	os.system(f"cat {cluster2}/scaling_max_freq")
	os.system(f"cat {cluster2}/scaling_governor")

def igpu_status():
	print("iGPU current state")
	os.system(f"cat {igpu}/gpu_max_clock")
	os.system(f"cat {igpu}/gpu_governor")


#Extra
def clear_cache():
	os.system("rm -rf storage/elumated/0/Android/data/*/cache /data/data/*/cache")