import os
import time

#Master variables (do not change)
igpu = "/sys/kernel/gpu"
cluster1 = "/sys/devices/system/cpu/cpufreq/policy0"
for cnum in range(1,9):
	hostdir = "/sys/devices/system/cpu/cpufreq/policy"
	if os.path.isdir(f"{hostdir}{cnum}") == True:
		cluster2 = f"{hostdir}{cnum}"
		break

c1a = open(f"{cluster1}/scaling_available_frequencies","r").read().split()
c2a = open(f"{cluster2}/scaling_available_frequencies","r").read().split()
c1g = open(f"{cluster1}/scaling_available_governors","r").read()
c2g = open(f"{cluster2}/scaling_available_governors","r").read()
gpa = open(f"{igpu}/gpu_freq_table").read()

#performance management
#CPU
def cpu_set(cluster, clock_value, clocks):
	if "." in clock_value:
		try:
			x = f"{clock_value[0]}{clock_value[2:4]}"
		except:
			exit()
		for value in clocks:
			if x in value:
				os.system(f"echo '{value}' > {cluster}/scaling_max_freq")
	elif "m" in clock_value:
		try:
			xi = f"{clock_value[0:3]}"
		except:
			exit()
		for values in clocks:
			if xi in values:
				os.system(f"echo '{values}' > {cluster}/scaling_max_freq")
	else:
		print("Err code 04: Failsafe activated")
		exit()

def cpu_gov_set(cluster, gov):
	os.system(f"echo '{gov}' > {cluster}/scaling_governor")

#iGPU
def gpu_set(clock, clocks):
	if clock in clocks:
		os.system(f"echo '{clock}' > /sys/kernel/gpu/gpu_max_clock")

def gpu_gov_set(gov):
	os.system(f"echo '{gov}' > /sys/kernel/gpu/gpu_governor")


#Status
#CPU
def cpu_available(c1a, c2a, c1g, c2g):
	
	print("\nCluster 1 options")
	for intr in c1a:
		if len(intr) > 6:
			print(f"{intr[0]}.{intr[1:3]}Ghz")
		elif len(intr) < 7:
			print(f"{intr[0:3]}Mhz")
	print(c1g)
	
	print("Cluster 2 options")
	for intx in c2a:
		if len(intx) > 6:
			print(f"{intx[0]}.{intx[1:3]}Ghz")
		elif len(intx) < 7:
			print(f"{intx[0:3]}Mhz")
	print(c2g)
	
#iGPU
def igpu_available():
	os.system(f"cat {igpu}/gpu_freq_table")
	os.system(f"cat {igpu}/gpu_available_governor")

#status info
def cpu_cluster1_status():
	os.system(f"cat {cluster1}/scaling_max_freq")
	os.system(f"cat {cluster1}/scaling_governor")
def cpu_cluster2_status():
	os.system(f"cat {cluster2}/scaling_max_freq")
	os.system(f"cat {cluster2}/scaling_governor")
#————————————
def igpu_status():
	print("iGPU current state")
	os.system(f"cat {igpu}/gpu_max_clock")
	os.system(f"cat {igpu}/gpu_governor")


#Extra
def clear_cache():
	os.system("rm -rf storage/elumated/0/Android/data/*/cache /data/data/*/cache")