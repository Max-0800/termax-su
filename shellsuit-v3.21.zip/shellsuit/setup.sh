cd $HOME
pkg update -y && pkg upgrade -y && pkg install x11-repo root-repo tsu python3 -y
unzip termax-su/shellsuit.zip &&
mv termax-su/shellsuit $HOME &&
mv termax-su/LISCENCE $HOME/shellsuit &&
rm -rf termax-su
echo "Thanks for installing Project Termax-SU by Max-0800"