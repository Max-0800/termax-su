#from threading import Thread
import random

def generate(digits):
	digits = int(digits)
	str = "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z a b c d e f g h i j k l m n o p q r s t u v w x y z 0 1 2 3 4 5 6 7 8 9 + × ÷ = / _ < > [ ] ! @ # $ % & * ( ) - ? ' "
	list = str.split()
	main = []
	ix1 = 0
	ix2 = 0
	
	while ix1 < digits:
		ix1 += 1
		x = random.choice(list)
		main.append(x)
		if len(main) == digits:
			print('\n', ''.join(main), '\n')
			print(f"Digits: {len(main)}")
