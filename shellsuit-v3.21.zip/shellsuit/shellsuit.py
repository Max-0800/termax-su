from SUbox import SUbox, passgen
from threading import *
import os, time

#Please Read the readme.txt file before modifying

os.system("clear")
print("\n Shellsuit/v3.01\n by Max-0800\n")
os.system("uname -smo&&date")


cluster1 = SUbox.cluster1
cluster2 = SUbox.cluster2
gpa = SUbox.gpa
c1av, c2av = SUbox.c1av, SUbox.c2av
c1gv, c2gv = SUbox.c1gv, SUbox.c2gv
c1cur, c2cur = SUbox.c1cur, SUbox.c2cur
c1max, c2max = c1av[-1], c2av[-1]
c1mid, c2mid = c1av[int(len(c1av)/2)], c2av[int(len(c2av)/2)]

threads = 0


if (c1cur <= c1max) or (c2cur <= c2max):
	print('\n HW: Device is underclocked!\n')


###########################

def main():
	global screenstate, pwrval, threads
	global cluster1, cluster2, gpa
	global c1av, c2av, c1gv, c2gv
	global c1cur, c2cur
	global c1mid, c2max, c1mid, c2mid
	
	tmx = input("/suit/:> ")
	zvar = tmx[15:22]
	xvar = tmx[9:14]
	gvar = tmx[9:]
	
	#CPU changing statements
	if "cpu -cm1 " in tmx:
		if "force" in tmx:
			SUbox.cpu_setforce(cluster1, zvar)
			print("Executed forced clock.\n\nCurrent cluster2 status:")
			SUbox.cpu_cluster1_status()
		else:
			SUbox.cpu_setsafe(cluster1, xvar, c1av)
			print("Executed safe clock.")
		print("Operation completed.")
		
	if "cpu -cm2 " in tmx:
		if "force" in tmx:
			SUbox.cpu_setforce(cluster2, zvar)
			print("Executed forced clock.\n\nCurrent cluster2 status:")
			SUbox.cpu_cluster2_status()
		else:
			SUbox.cpu_setsafe(cluster2, xvar, c2av)
			print("Executed safe clock.")
		print("Operation completed.")
		
	#CPU governor changing statements
	if "cpu -gm1 " in tmx:
		SUbox.cpu_gov_set(cluster1, gvar)
		print("Operation completed.")
	elif "cpu -gm2 " in tmx:
		SUbox.cpu_gov_set(cluster2, gvar)
		print("Operationg completed.")
	
	#iGPU changing statements
	if "gpu -clk " in tmx:
		SUbox.gpu_set(xvar, gpa)
		print(f"iGPU clock speed has been set to {xvar}Mhz")
	elif "gpu -gov " in tmx:
		SUbox.gpu_gov_set(xvar)
		print(f"iGPU governor has been set to {xvar}")
	
	#CPU optional pre-clocks
	if "clock mid" in tmx:
		clock_mid()
	elif "clock max" in tmx:
		clock_max()
	
	################
	
	#Informational statements
	if tmx == "cpu c":
		exc = False
		SUbox.cpu_available(exc, c1av, c2av, c1gv, c2gv)
	elif tmx == "cpu cr":
		exc = True
		SUbox.cpu_available(exc, c1av, c2av, c1gv, c2gv)
	elif tmx == "cpu si":
		if (c1cur == c1mid) and (c2cur == c2mid):
			print("POWERSAVE is currently Enabled")
		elif (c1cur == c1mid) and (c2cur == c2max):
			print("POWERSAVE is currently Disabled")
		SUbox.cpu_cluster1_status()
		SUbox.cpu_cluster2_status()
	if tmx == "gpu c":
		SUbox.igpu_available()
	elif tmx == "gpu si":
		SUbox.igpu_status()
	
	#PROCESS
	if tmx == "get proc":
		print("SHOWING ACTIVE APP PROCESS\n\n")
		os.system("ps aux | grep com. | sort")
	
	#Miscellaneous
	if tmx == "sudo reboot":
		os.system("sudo reboot")
	elif tmx == "clear cache":
		SUbox.clear_cache()
		print("cache cleared")
	
	if tmx == "help":
		print("Commands")
		print(open("help.txt", 'r').read())
	elif tmx == "cls":
		os.system("clear")
	
	if "generate " in tmx:
		passgen.generate(tmx[8:])
	

###########################

def clock_mid():
	SUbox.cpu_setsafe(cluster1, c1mid, c1av)
	SUbox.cpu_setsafe(cluster2, c2mid, c2av)
	print("All CPU clusters have been set to 50% max clock speed, expect lower performance and frame rate as device is underclocked (excluding GPU)")

def clock_max():
	SUbox.cpu_setsafe(cluster1, c1max, c1av)
	SUbox.cpu_setsafe(cluster2, c2max, c2av)
	print("All CPU clusters are now clocked at 100% capacity. (excluding GPU)")

###########################

#Loopback
while True:
	main()
